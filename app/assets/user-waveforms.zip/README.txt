Public bundle intentionally contains no third-party waves. Two original built-in waves are defined in pulse_library.dart. Import your own licensed files in the app.
